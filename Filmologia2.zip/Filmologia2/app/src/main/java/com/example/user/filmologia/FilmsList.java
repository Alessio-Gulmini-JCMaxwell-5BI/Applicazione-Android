package com.example.user.filmologia;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by User on 30/06/2017.
 */

public class FilmsList extends ArrayAdapter<Films>{

    private Activity context;
    private List<Films> filmList;

    public FilmsList(Activity context, List<Films> FilmsList){
        super(context, R.layout.list, FilmsList);
        this.context = context;
        this.filmList = FilmsList;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.list, null, true);

        TextView title = (TextView) listViewItem.findViewById(R.id.textTitle);
        TextView year = (TextView) listViewItem.findViewById(R.id.textYear);
        TextView rating = (TextView) listViewItem.findViewById(R.id.textRating);

        Films film = filmList.get(position);

        title.setText(film.getFilmTitle());
        year.setText(film.getFilmYear());
        rating.setText(film.getFilmRating());

        return listViewItem;


    }
}
