package com.example.user.filmologia;

/**
 * Created by User on 30/06/2017.
 */

public class Films {

    String filmId;
    String filmTitle;
    String filmYear;
    String filmWatch;
    String filmRating;


    public Films(String filmId, String filmTitle, String filmYear, String filmWatch, String filmRating) {
        this.filmId = filmId;
        this.filmTitle = filmTitle;
        this.filmYear = filmYear;
        this.filmRating = filmRating;

    }

    public String getFilmWatch() {
        return filmWatch;
    }

    public String getFilmRating() {
        return filmRating;
    }

    public void setFilmWatch(String filmWatch) {
        this.filmWatch = filmWatch;
    }

    public void setFilmRating(String filmRating) {
        this.filmRating = filmRating;
    }

    public String getFilmId() {
        return filmId;
    }

    public String getFilmTitle() {
        return filmTitle;
    }

    public String getFilmYear() {
        return filmYear;
    }

    public void setFilmId(String filmId) {
        this.filmId = filmId;
    }

    public void setFilmTitle(String filmTitle) {
        this.filmTitle = filmTitle;
    }

    public void setFilmYear(String filmYear) {
        this.filmYear = filmYear;
    }

}
