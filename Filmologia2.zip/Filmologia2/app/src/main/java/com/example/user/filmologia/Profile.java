package com.example.user.filmologia;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Profile extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth firebaseAuth;

    DatabaseReference databaseFilms;

    ListView listViewFilms;
    List<Films> filmsList;

    private TextView textViewUserEmail;
    private Button buttonLogout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        databaseFilms = FirebaseDatabase.getInstance().getReference("film");
        firebaseAuth = FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser() == null)
        {
            finish();
            startActivity(new Intent(this, Login.class));
        }
        FirebaseUser user = firebaseAuth.getCurrentUser();

        textViewUserEmail = (TextView) findViewById(R.id.textViewUserEmail);

        textViewUserEmail.setText("Welcome " + user.getEmail());

        Button addFilms = (Button) findViewById(R.id.buttonAddFilm);

        listViewFilms = (ListView) findViewById(R.id.listViewFilms);
        filmsList = new ArrayList<>();

        addFilms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(Profile.this);

                View mView = getLayoutInflater().inflate(R.layout.add_movies, null);


                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();
                final Button addMovie = (Button) mView.findViewById(R.id.buttonAddMovie);

                final EditText editTitle = (EditText) mView.findViewById(R.id.editTitle);
                final EditText editYear = (EditText) mView.findViewById(R.id.editYear);
                final EditText editRating = (EditText) mView.findViewById(R.id.editRating);
                final Spinner editWatch = (Spinner) mView.findViewById(R.id.editWatch);

                addMovie.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String title = editTitle.getText().toString().trim();
                        String year = editYear.getText().toString().trim();
                        String rating = editRating.getText().toString().trim();
                        String watch = editWatch.getSelectedItem().toString();

                        addMovie(title, year, rating, watch);



                    }
                });
            }


            private void addMovie(String title, String year, String rating, String watch){

                if(!TextUtils.isEmpty(title) && !TextUtils.isEmpty(year))
                {
                    String id = databaseFilms.push().getKey();

                    Films film = new Films(id, title, year, watch, rating);

                    databaseFilms.child(id).setValue(film);

                    Toast.makeText(Profile.this, "Film added", Toast.LENGTH_LONG).show();
                }

                else
                {
                    Toast.makeText(Profile.this, "You should enter all respective fields", Toast.LENGTH_LONG).show();
                }

            }
        });

        buttonLogout = (Button) findViewById(R.id.buttonLogout);
        buttonLogout.setOnClickListener(this);

    }


    //This is the read function that makes the app crash
    @Override
    protected void onStart() {
        super.onStart();

        databaseFilms.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                filmsList.clear();

                for(DataSnapshot filmSnapshot : dataSnapshot.getChildren())
                {
                    Films film = filmSnapshot.getValue(Films.class);

                    filmsList.add(film);
                }

                FilmList adapter = new FilmList(Profile.this, filmsList);
                listViewFilms.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }



    @Override
    public void onClick(View view) {
        if(view == buttonLogout)
        {
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this, Login.class));
        }
    }
}